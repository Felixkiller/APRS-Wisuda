"""Parsing & pembuatan paket pesan APRS (fungsi murni, mudah diuji)."""

import re
import unicodedata
from collections import namedtuple

TOCALL = "APZWSD"      # APZxxx = tocall eksperimental
MAX_MSG_LEN = 67       # batas panjang teks pesan APRS

MessagePacket = namedtuple("MessagePacket", "src addressee text msgid")

_HEADER_RE = re.compile(r"^([A-Za-z0-9\-]{1,9})>([^:]*):(.*)$", re.S)
_MSGID_RE = re.compile(r"\{([A-Za-z0-9]{1,5})\}?([A-Za-z0-9]{0,5})$")
ACK_RE = re.compile(r"^(ack|rej)([A-Za-z0-9]{1,5})$")


def parse_message_packet(line):
    """
    Parse satu baris APRS-IS. Return MessagePacket kalau itu paket pesan,
    selain itu None.

        SRC>DST,PATH,qAC,IGATE::ADDRESSEE:teks{123
    """
    m = _HEADER_RE.match(line)
    if not m:
        return None
    src, _path, body = m.group(1).upper(), m.group(2), m.group(3)
    # body pesan: ':' + 9 karakter penerima + ':' + teks
    if len(body) < 11 or body[0] != ":" or body[10] != ":":
        return None
    addressee = body[1:10].strip().upper()
    text = body[11:]
    msgid = None
    mid = _MSGID_RE.search(text)
    if mid:
        msgid = mid.group(1)
        text = text[:mid.start()]
    return MessagePacket(src, addressee, text.rstrip("\r\n"), msgid)


def sanitize_text(text):
    """ASCII saja, tanpa karakter terlarang APRS ({ | ~), satu baris."""
    text = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode()
    text = re.sub(r"[\r\n\t]+", " ", text)
    text = re.sub(r"[{|~]", "", text)
    return re.sub(r" {2,}", " ", text).strip()


def split_message(text, limit=MAX_MSG_LEN):
    """Pecah teks jadi potongan <= limit karakter, memotong di batas kata."""
    parts, cur = [], ""
    for word in text.split():
        while len(word) > limit:           # kata super panjang: potong paksa
            if cur:
                parts.append(cur)
                cur = ""
            parts.append(word[:limit])
            word = word[limit:]
        candidate = f"{cur} {word}".strip()
        if len(candidate) > limit:
            parts.append(cur)
            cur = word
        else:
            cur = candidate
    if cur:
        parts.append(cur)
    return parts


def format_message(src, dest, text, msgid=None, tocall=TOCALL):
    pkt = f"{src}>{tocall},TCPIP*::{dest.upper().ljust(9)}:{text}"
    if msgid:
        pkt += "{" + str(msgid)
    return pkt


def format_ack(src, dest, msgid, tocall=TOCALL):
    return format_message(src, dest, f"ack{msgid}", tocall=tocall)


def format_status(src, text, tocall=TOCALL):
    return f"{src}>{tocall},TCPIP*:>{sanitize_text(text)}"


def _fmt_coord(value, deg_digits, hemis):
    hundredths = round(abs(value) * 6000)          # 1/100 menit busur
    deg, rem = divmod(hundredths, 6000)
    return f"{deg:0{deg_digits}d}{rem / 100:05.2f}{hemis[0 if value >= 0 else 1]}"


def format_position(src, lat, lon, symbol, comment="", tocall=TOCALL):
    table, code = symbol[0], symbol[1]
    return (f"{src}>{tocall},TCPIP*:!{_fmt_coord(lat, 2, 'NS')}{table}"
            f"{_fmt_coord(lon, 3, 'EW')}{code}{sanitize_text(comment)}")
