"""
Konfigurasi APRS Bot Wisuda - Ilmu Informatika UKDC

Yang WAJIB kamu isi sebelum dipakai di udara:
  - APRS_CALLSIGN  : call sign (+SSID) milik bot, mis. YD3XXX-5
  - APRS_PASSCODE  : passcode APRS-IS untuk call sign tersebut (BUKAN password email)

Cara termudah: salin `.env.example` menjadi `.env` lalu isi dua baris itu.
(Environment variable dengan nama yang sama juga bisa dipakai dan menang atas .env.)
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _load_dotenv(path):
    """Baca file .env sederhana (KEY=VALUE per baris) tanpa library tambahan."""
    try:
        with open(path, encoding="utf-8-sig") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))
    except OSError:
        pass


_load_dotenv(os.path.join(BASE_DIR, ".env"))

IMAGES_DIR = os.path.join(BASE_DIR, "modules", "images")
GENERATED_CARDS_DIR = os.path.join(BASE_DIR, "generated_cards")
LOG_DIR = os.path.join(BASE_DIR, "logs")
TIMEZONE = "Asia/Jakarta"

# ------------------------------------------------------------------
# Identitas & koneksi APRS-IS
# ------------------------------------------------------------------
CALLSIGN = os.environ.get("APRS_CALLSIGN", "N0CALL-5").strip().upper()
APRS_PASSCODE = os.environ.get("APRS_PASSCODE", "-1").strip()
APRS_SERVER = os.environ.get("APRS_SERVER", "rotate.aprs2.net")
APRS_PORT = int(os.environ.get("APRS_PORT", "14580"))

# ------------------------------------------------------------------
# Perilaku bot
# ------------------------------------------------------------------
# Jeda minimal antar perintah dari call sign yang sama (detik)
RATE_LIMIT_SECONDS = 20
# Batas balasan per call sign per jam (mencegah loop antar-bot)
MAX_REPLIES_PER_HOUR = 20
# True = bot hanya menjawab "wisuda" pada rentang date_start..date_end event
ENFORCE_EVENT_WINDOW = False

# Beacon status supaya bot terlihat di aprs.fi (0 = nonaktif)
BEACON_INTERVAL = 1800  # detik
BEACON_TEXT = "Bot Wisuda Ilmu Informatika UKDC - kirim pesan: WISUDA"
# Isi (lat, lon) desimal kalau mau tampil di peta, mis. (-7.2575, 112.7521)
# Biarkan None kalau tidak mau memasang posisi.
BEACON_POSITION = None
BEACON_SYMBOL = "/-"  # tabel + kode simbol APRS (default: rumah)

# ------------------------------------------------------------------
# Event
# ------------------------------------------------------------------
EVENTS_2026 = {
    "wisuda": {
        "name": "Wisuda 2026",
        "title": "WISUDA 2026",
        "date": "2026-12-01",           # GANTI sesuai tanggal wisuda
        "date_start": "2026-11-25",
        "date_end": "2026-12-05",
        "greeting": (
            "Selamat Wisuda! Semoga ilmu yang diraih bermanfaat, "
            "membawa berkah, dan sukses selalu untuk ke depannya. 73!"
        ),
        "quote": (
            "Semoga ilmu yang diraih bermanfaat, membawa berkah, "
            "dan sukses selalu untuk ke depannya"
        ),
        "image": os.path.join(IMAGES_DIR, "wisuda_art.png"),
        "qsl": {"band": "2M", "freq": "144.390", "rst": "59", "mode": "PKT"},
        "command_trigger": "wisuda",
    },
}
