"""
Command: wisuda - QSL Card Wisuda

Trigger: Kirim pesan "wisuda" ke bot
Response: Ucapan Wisuda + QSL card personalized (call sign pengirim,
          tanggal & jam UTC, band, freq, RST, mode, operator)
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from event_manager import get_event_by_trigger
from qsl_generator import generate_qsl_card
from statistics import log_callsign, log_event


def handle_command(from_call=None, qso_time=None):
    """
    Handler untuk command 'wisuda'.

    Args:
        from_call: Call sign pengirim
        qso_time: datetime saat pesan pengirim DITERIMA (tanggal & jam di QSL).
                  Default None = saat kartu dibuat.

    Returns:
        str: Pesan balasan ucapan Wisuda
    """
    event_key, event_config = get_event_by_trigger("wisuda")

    if not event_config:
        return "Event Wisuda belum dikonfigurasi."

    greeting = event_config.get("greeting", "Selamat Wisuda!")

    if from_call:
        log_callsign(from_call, event_config["name"], "wisuda")
        log_event("RECEIVED", from_call, "Command: wisuda")

        card_path = generate_qsl_card(from_call, event_config, qso_time=qso_time)
        if card_path:
            log_event("CARD_GENERATED", from_call, f"QSL: {card_path}")
            print(f"[WISUDA] QSL generated for {from_call}: {card_path}")

        log_event("REPLIED", from_call, "Greeting sent for Wisuda")
        return f"Hai {from_call}! {greeting}"

    return greeting
