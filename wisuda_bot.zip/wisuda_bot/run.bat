@echo off
rem Pasang dependensi (sekali) lalu jalankan bot. Contoh: run.bat   atau   run.bat --dry-run
cd /d "%~dp0"
if not exist .venv ( python -m venv .venv )
.venv\Scripts\python.exe -m pip install -q -r requirements.txt
.venv\Scripts\python.exe aprs_bot.py %*
pause
