"""Router perintah: teks pesan APRS masuk -> teks balasan."""

import config
from event_manager import describe_window, get_event_by_trigger, is_event_active
from modules import wisuda

# trigger -> handler(from_call) -> str
COMMANDS = {
    "wisuda": wisuda.handle_command,
}

HELP_TEXT = "Kirim pesan WISUDA ke bot ini untuk ucapan + QSL card Wisuda. 73!"


def process_command(from_call, text, received_at=None):
    """
    Return teks balasan (boleh panjang; bot yang memecahnya per 67 karakter).

    received_at: datetime (UTC) saat pesan pengirim diterima; dipakai sebagai
    tanggal & jam QSO di QSL card.
    """
    words = (text or "").strip().split()
    cmd = words[0].lower().lstrip("!/.#") if words else ""

    if cmd in ("", "help", "?", "info", "menu"):
        return HELP_TEXT

    handler = COMMANDS.get(cmd)
    if handler is None:
        return "Perintah tidak dikenal. Kirim WISUDA untuk QSL Wisuda, atau HELP."

    _key, event = get_event_by_trigger(cmd)
    if config.ENFORCE_EVENT_WINDOW and event and not is_event_active(event):
        return f"Event {event['name']} aktif {describe_window(event)}. Sampai jumpa! 73"

    return handler(from_call, qso_time=received_at)
