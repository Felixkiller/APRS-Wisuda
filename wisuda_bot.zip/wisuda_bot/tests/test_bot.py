"""
Tes APRS Bot Wisuda.   Jalankan:  python -m unittest discover -s tests -v

Mencakup: parsing/format paket, pemecahan 67 karakter, router perintah,
pembuatan QSL card, dan alur lengkap lawan server APRS-IS palsu (login,
ACK, balasan multi-bagian, retry, duplikat, mode tidak-terverifikasi).
"""

import os
import socket
import sys
import tempfile
import threading
import time
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import config  # noqa: E402

# Arahkan keluaran tes ke folder sementara SEBELUM modul lain meng-import config
_TMP = tempfile.mkdtemp(prefix="wisuda_test_")
config.GENERATED_CARDS_DIR = os.path.join(_TMP, "cards")
config.LOG_DIR = os.path.join(_TMP, "logs")
config.CALLSIGN = "YD3TEST-5"
config.BEACON_INTERVAL = 0
config.RATE_LIMIT_SECONDS = 0

import aprs_bot  # noqa: E402
import aprs_packets as ap  # noqa: E402
from commands import process_command  # noqa: E402

aprs_bot.PART_GAP = 0.02


class PacketTests(unittest.TestCase):
    def test_parse_message_with_id(self):
        p = ap.parse_message_packet("YB1ABC-7>APRS,TCPIP*,qAC,T2X::YD3TEST-5:wisuda{12")
        self.assertEqual((p.src, p.addressee, p.text, p.msgid),
                         ("YB1ABC-7", "YD3TEST-5", "wisuda", "12"))

    def test_parse_message_without_id_and_reply_ack(self):
        p = ap.parse_message_packet("YB1ABC>APRS::YD3TEST-5:halo")
        self.assertEqual((p.text, p.msgid), ("halo", None))
        p = ap.parse_message_packet("YB1ABC>APRS::YD3TEST-5:wisuda{12}34")
        self.assertEqual((p.text, p.msgid), ("wisuda", "12"))

    def test_non_message_packets_ignored(self):
        self.assertIsNone(ap.parse_message_packet("YB1ABC>APRS,TCPIP*:>status saja"))
        self.assertIsNone(ap.parse_message_packet("garbage"))

    def test_split_respects_limit(self):
        text = ("Hai YB1ABC-7! Selamat Wisuda! Semoga ilmu yang diraih bermanfaat, "
                "membawa berkah, dan sukses selalu untuk ke depannya. 73!")
        parts = ap.split_message(text)
        self.assertGreater(len(parts), 1)
        self.assertTrue(all(len(x) <= ap.MAX_MSG_LEN for x in parts))
        self.assertEqual(" ".join(parts), text)
        self.assertEqual([len(x) <= 67 for x in ap.split_message("x" * 200)], [True] * 3)

    def test_sanitize(self):
        self.assertEqual(ap.sanitize_text("a{b|c~d\ne  f é"), "abcd e f e")

    def test_format_message_and_ack(self):
        self.assertEqual(ap.format_message("YD3TEST-5", "YB1ABC", "hi", "7"),
                         "YD3TEST-5>APZWSD,TCPIP*::YB1ABC   :hi{7")
        self.assertEqual(ap.format_ack("YD3TEST-5", "YB1ABC-7", "12"),
                         "YD3TEST-5>APZWSD,TCPIP*::YB1ABC-7 :ack12")

    def test_position_format(self):
        self.assertEqual(ap.format_position("A", -7.2575, 112.7521, "/-", "x"),
                         "A>APZWSD,TCPIP*:!0715.45S/11245.13E-x")


class CommandTests(unittest.TestCase):
    def test_help_and_unknown(self):
        self.assertIn("WISUDA", process_command("YB1ABC", "help"))
        self.assertIn("tidak dikenal", process_command("YB1ABC", "foo"))

    def test_wisuda_makes_card(self):
        reply = process_command("YB1ABC-7", "  WISUDA  ")
        self.assertTrue(reply.startswith("Hai YB1ABC-7! Selamat Wisuda!"))
        cards = os.listdir(config.GENERATED_CARDS_DIR)
        self.assertTrue(any(c.startswith("wisuda_YB1ABC-7_") and c.endswith(".png") for c in cards))
        self.assertTrue(os.path.exists(os.path.join(config.LOG_DIR, "callsigns.csv")))

    def test_event_window(self):
        config.ENFORCE_EVENT_WINDOW = True
        try:
            ev = config.EVENTS_2026["wisuda"]
            old = ev["date_start"], ev["date_end"]
            ev["date_start"], ev["date_end"] = "2000-01-01", "2000-01-02"
            self.assertIn("aktif 01-01-2000 s/d 02-01-2000", process_command("YB1ABC", "wisuda"))
            ev["date_start"], ev["date_end"] = old
        finally:
            config.ENFORCE_EVENT_WINDOW = False


class ReceiveTimeTests(unittest.TestCase):
    def test_wisuda_passes_receive_time_to_card(self):
        from datetime import datetime, timezone
        from modules import wisuda
        seen = {}
        original = wisuda.generate_qsl_card
        wisuda.generate_qsl_card = lambda call, ev, qso_time=None, **kw: seen.update(
            call=call, qso_time=qso_time)
        try:
            when = datetime(2026, 12, 1, 3, 4, tzinfo=timezone.utc)
            process_command("YB1ABC-7", "wisuda", when)
        finally:
            wisuda.generate_qsl_card = original
        self.assertEqual(seen, {"call": "YB1ABC-7", "qso_time": when})

    def test_card_uses_given_date_and_time(self):
        """Render sungguhan dengan waktu tetap: kartu harus memuat tanggal itu."""
        from datetime import datetime, timezone
        from PIL import Image
        import qsl_generator
        out = os.path.join(_TMP, "fixed.png")
        when = datetime(2026, 12, 1, 3, 4, tzinfo=timezone.utc)
        qsl_generator.generate_qsl_card("YB1ABC-7", config.EVENTS_2026["wisuda"],
                                        qso_time=when, output_path=out)
        self.assertTrue(os.path.exists(out))
        self.assertEqual(Image.open(out).size, (1714, 1208))

    def test_dotenv_loader(self):
        path = os.path.join(_TMP, "x.env")
        with open(path, "w", encoding="utf-8") as f:
            f.write('# komentar\nWISUDA_T1="abc"\nWISUDA_T2 = 42\nrusak\n')
        os.environ.pop("WISUDA_T1", None)
        os.environ["WISUDA_T2"] = "dari-env"          # env menang atas .env
        config._load_dotenv(path)
        self.assertEqual(os.environ["WISUDA_T1"], "abc")
        self.assertEqual(os.environ["WISUDA_T2"], "dari-env")


class FakeAprsIs:
    """Server APRS-IS palsu: terima login, kirim paket, rekam semua baris dari bot."""

    def __init__(self, verified=True, auto_ack=True):
        self.verified, self.auto_ack = verified, auto_ack
        self.lines, self.cond = [], threading.Condition()
        self.srv = socket.socket()
        self.srv.bind(("127.0.0.1", 0))
        self.srv.listen(1)
        self.port = self.srv.getsockname()[1]
        self.conn = None
        threading.Thread(target=self._serve, daemon=True).start()

    def _serve(self):
        self.conn, _ = self.srv.accept()
        self.conn.sendall(b"# fake-aprsd 0.1\r\n")
        buf = b""
        while True:
            try:
                data = self.conn.recv(4096)
            except OSError:
                return
            if not data:
                return
            buf += data
            while b"\n" in buf:
                raw, buf = buf.split(b"\n", 1)
                line = raw.decode().strip()
                with self.cond:
                    self.lines.append(line)
                    self.cond.notify_all()
                if line.startswith("user "):
                    word = "verified" if self.verified else "unverified"
                    self.conn.sendall(f"# logresp YD3TEST-5 {word}, server FAKE\r\n".encode())
                elif self.auto_ack and "::YB1ABC-7 :" in line and "{" in line:
                    msgid = line.rsplit("{", 1)[1]
                    self.send(f"YB1ABC-7>APRS,TCPIP*::YD3TEST-5:ack{msgid}")

    def send(self, packet):
        self.conn.sendall(packet.encode() + b"\r\n")

    def wait_for(self, predicate, timeout=5):
        end = time.time() + timeout
        with self.cond:
            while time.time() < end:
                hits = [l for l in self.lines if predicate(l)]
                if hits:
                    return hits
                self.cond.wait(0.1)
        return []

    def close(self):
        for s in (self.conn, self.srv):
            try:
                s and s.close()
            except OSError:
                pass


class EndToEndTests(unittest.TestCase):
    def start(self, **kw):
        self.server = FakeAprsIs(**{k: kw.pop(k) for k in ("verified", "auto_ack") if k in kw})
        self.bot = aprs_bot.AprsBot(server="127.0.0.1", port=self.server.port, **kw)
        self.thread = threading.Thread(target=self.bot.run, daemon=True)
        self.thread.start()
        # tunggu login selesai
        self.server.wait_for(lambda l: l.startswith("user "))
        time.sleep(0.3)

    def tearDown(self):
        self.bot.stop()
        self.server.close()

    def replies(self):
        return [l for l in self.server.lines if "::YB1ABC-7 :" in l and ":ack" not in l]

    def test_login_line(self):
        self.start()
        login = self.server.lines[0]
        self.assertEqual(login, "user YD3TEST-5 pass -1 vers wisuda-bot 1.0 filter g/YD3TEST-5")

    def test_full_wisuda_flow_with_acks(self):
        self.start()
        self.server.send("YB1ABC-7>APRS,TCPIP*,qAC,T2X::YD3TEST-5:wisuda{12")
        acks = self.server.wait_for(lambda l: l.endswith(":ack12"))
        self.assertEqual(acks, ["YD3TEST-5>APZWSD,TCPIP*::YB1ABC-7 :ack12"])

        # balasan multi-bagian, tiap bagian <= 67 karakter, masing-masing punya msgid
        deadline = time.time() + 5
        while time.time() < deadline and len(self.replies()) < 3:
            time.sleep(0.05)
        replies = self.replies()
        self.assertGreaterEqual(len(replies), 2)
        texts = []
        for line in replies:
            body, msgid = line.rsplit("{", 1)
            self.assertTrue(msgid.isdigit())
            text = body.split("::YB1ABC-7 :", 1)[1]
            self.assertLessEqual(len(text), 67)
            texts.append(text)
        full = " ".join(texts)
        self.assertTrue(full.startswith("Hai YB1ABC-7! Selamat Wisuda!"))
        self.assertTrue(full.endswith("73!"))

        # ACK dari server palsu membersihkan antrean retry
        time.sleep(0.5)
        self.assertEqual(self.bot.pending, {})
        self.assertTrue(any(c.endswith(".png") for c in os.listdir(config.GENERATED_CARDS_DIR)))

    def test_duplicate_is_acked_but_answered_once(self):
        self.start()
        pkt = "YB1ABC-7>APRS,TCPIP*::YD3TEST-5:help{5"
        self.server.send(pkt)
        time.sleep(0.4)
        self.server.send(pkt)
        time.sleep(0.6)
        acks = [l for l in self.server.lines if l.endswith(":ack5")]
        self.assertEqual(len(acks), 2)
        self.assertEqual(len(self.replies()), 1)  # HELP = 1 pesan, bukan 2 (duplikat tidak dijawab ulang)

    def test_retry_when_not_acked(self):
        old = aprs_bot.RETRY_INTERVALS
        aprs_bot.RETRY_INTERVALS = (0.2, 0.2, 0.2)
        try:
            self.start(auto_ack=False)
            self.server.send("YB1ABC-7>APRS::YD3TEST-5:hi{9")
            time.sleep(2.5)
            sent = [l for l in self.replies() if "Perintah tidak dikenal" in l.split("::")[-1]
                    or "Perintah" in l]
            self.assertGreaterEqual(len(sent), 2, self.server.lines)
        finally:
            aprs_bot.RETRY_INTERVALS = old

    def test_ignores_other_addressee_and_own_acks(self):
        self.start()
        self.server.send("YB1ABC-7>APRS::YD9OTHER-1:wisuda{1")
        self.server.send("YB1ABC-7>APRS::YD3TEST-5:ack77")
        time.sleep(0.6)
        self.assertEqual([l for l in self.server.lines if "::YB1ABC-7 :" in l], [])

    def test_unverified_login_never_transmits(self):
        self.start(verified=False)
        self.server.send("YB1ABC-7>APRS::YD3TEST-5:wisuda{3")
        time.sleep(1.0)
        self.assertEqual([l for l in self.server.lines if not l.startswith("user ")], [])

    def test_dry_run_never_transmits(self):
        self.start(dry_run=True)
        self.server.send("YB1ABC-7>APRS::YD3TEST-5:help{3")
        time.sleep(1.0)
        self.assertEqual([l for l in self.server.lines if not l.startswith("user ")], [])

    def test_receive_time_is_captured_on_arrival(self):
        from datetime import datetime, timezone
        captured = {}
        original = aprs_bot.process_command
        aprs_bot.process_command = lambda src, text, at=None: captured.update(at=at) or "ok"
        try:
            self.start()
            before = datetime.now(timezone.utc)
            self.server.send("YB1ABC-7>APRS::YD3TEST-5:wisuda{21")
            self.server.wait_for(lambda l: "::YB1ABC-7 :ok" in l)
            after = datetime.now(timezone.utc)
        finally:
            aprs_bot.process_command = original
        self.assertTrue(before <= captured["at"] <= after, captured)

    def test_rate_limit(self):
        config.RATE_LIMIT_SECONDS = 60
        try:
            self.start()
            self.server.send("YB1ABC-7>APRS::YD3TEST-5:help{1")
            time.sleep(0.5)
            first = len(self.replies())
            self.server.send("YB1ABC-7>APRS::YD3TEST-5:help{2")
            time.sleep(0.8)
            self.assertEqual(len(self.replies()), first)
            self.assertTrue(any(l.endswith(":ack2") for l in self.server.lines))
        finally:
            config.RATE_LIMIT_SECONDS = 0


if __name__ == "__main__":
    unittest.main()
