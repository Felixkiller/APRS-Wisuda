#!/usr/bin/env python3
"""
APRS Bot Wisuda - Ilmu Informatika UKDC

Alur (seperti QSL card: kirim pesan -> dapat balasan):
  1. Bot login ke APRS-IS dengan filter pesan yang ditujukan ke call sign bot.
  2. Pesan masuk "WISUDA" -> bot kirim ACK, lalu balas ucapan (dipecah per 67
     karakter, dengan retry sampai di-ACK) dan membuat QSL card PNG personal.
  3. Beacon status berkala supaya bot terlihat di aprs.fi.

Pakai:
    python aprs_bot.py                      # jalankan bot
    python aprs_bot.py --dry-run            # konek & baca, tapi TIDAK memancarkan
    python aprs_bot.py --simulate YB1ABC-7 wisuda   # tes offline tanpa jaringan
"""

import argparse
import logging
import queue
import random
import re
import signal
import socket
import threading
import time
from collections import defaultdict, deque
from datetime import datetime, timezone

import config
from aprs_packets import (format_ack, format_message, format_position,
                          format_status, parse_message_packet, sanitize_text,
                          split_message, ACK_RE)
from commands import process_command

log = logging.getLogger("aprsbot")

SOFTWARE, VERSION = "wisuda-bot", "1.0"
PART_GAP = 1.5                      # jeda antar potongan balasan (detik)
RETRY_INTERVALS = (20, 40, 80)      # jeda retry pesan keluar (detik)
MAX_RETRIES = 3
DEDUPE_TTL_ID = 300                 # pesan dengan msgid: abaikan duplikat 5 menit
DEDUPE_TTL_NOID = 30                # tanpa msgid: 30 detik
SILENCE_LIMIT = 90                  # putus & konek ulang kalau server diam >90 dtk

_LOGRESP_RE = re.compile(r"logresp\s+\S+\s+(verified|unverified)", re.I)


class AprsBot:
    def __init__(self, callsign=None, passcode=None, server=None, port=None,
                 dry_run=False):
        self.callsign = (callsign or config.CALLSIGN).upper()
        self.passcode = str(passcode if passcode is not None else config.APRS_PASSCODE)
        self.server = server or config.APRS_SERVER
        self.port = int(port or config.APRS_PORT)
        self.dry_run = dry_run

        self.sock = None
        self._buf = b""
        self.can_transmit = False
        self.stop_event = threading.Event()
        self._send_lock = threading.Lock()

        self.work_q = queue.Queue()
        self.pending = {}                       # (dest, msgid) -> entry
        self._pending_lock = threading.Lock()
        self._seen = {}                         # (src, msgid, text) -> waktu
        self._last_cmd = {}                     # src -> waktu perintah terakhir
        self._replies = defaultdict(deque)      # src -> waktu balasan (1 jam)
        self._msg_counter = random.randint(1, 900)
        self._beacon_due = False
        self._next_beacon = 0.0

    # ------------------------------------------------------------------
    # Siklus hidup
    # ------------------------------------------------------------------
    def run(self):
        for target in (self._worker_loop, self._retry_loop, self._beacon_loop):
            threading.Thread(target=target, daemon=True).start()

        backoff = 5
        while not self.stop_event.is_set():
            try:
                self._connect()
                backoff = 5
                self._read_loop()
            except OSError as exc:
                if not self.stop_event.is_set():
                    log.warning("Koneksi APRS-IS terputus: %s", exc)
            finally:
                self.can_transmit = False
                self._close()
            if self.stop_event.wait(backoff):
                break
            backoff = min(backoff * 2, 60)

    def stop(self):
        self.stop_event.set()
        self._close()

    def _close(self):
        sock, self.sock = self.sock, None
        if sock:
            try:
                sock.close()
            except OSError:
                pass

    # ------------------------------------------------------------------
    # Koneksi APRS-IS
    # ------------------------------------------------------------------
    def _connect(self):
        log.info("Menghubungkan ke %s:%s sebagai %s ...", self.server, self.port, self.callsign)
        sock = socket.create_connection((self.server, self.port), timeout=15)
        sock.settimeout(30)
        self.sock = sock
        self._buf = b""
        login = (f"user {self.callsign} pass {self.passcode} vers {SOFTWARE} {VERSION} "
                 f"filter g/{self.callsign}")
        self._send_raw(login)

    def _read_loop(self):
        last_data = time.time()
        while not self.stop_event.is_set():
            sock = self.sock
            if sock is None:
                return
            try:
                data = sock.recv(4096)
            except socket.timeout:
                if time.time() - last_data > SILENCE_LIMIT:
                    raise ConnectionError("server diam lebih dari 90 detik")
                continue
            if not data:
                raise ConnectionError("server menutup koneksi")
            last_data = time.time()
            self._buf += data
            while b"\n" in self._buf:
                raw, self._buf = self._buf.split(b"\n", 1)
                line = raw.decode("latin-1").strip()
                if line:
                    self.handle_line(line)

    def _send_raw(self, line):
        with self._send_lock:
            if self.sock is None:
                raise ConnectionError("tidak terhubung")
            self.sock.sendall(line.encode("latin-1", "replace") + b"\r\n")

    def _transmit(self, line):
        """Kirim paket ke APRS-IS (hanya kalau login terverifikasi & bukan dry-run)."""
        if not self.can_transmit:
            log.info("[TIDAK DIKIRIM - mode baca saja] %s", line)
            return False
        try:
            self._send_raw(line)
            log.debug("TX %s", line)
            return True
        except OSError as exc:
            log.warning("Gagal kirim: %s", exc)
            return False

    # ------------------------------------------------------------------
    # Penanganan paket masuk
    # ------------------------------------------------------------------
    def handle_line(self, line):
        if line.startswith("#"):
            self._handle_server_comment(line)
            return

        # APRS tidak membawa cap waktu di paket pesan, jadi saat paket tiba di
        # bot = waktu QSO yang dicetak di QSL card (selisih detik dari saat dikirim).
        received_at = datetime.now(timezone.utc)
        pkt = parse_message_packet(line)
        if pkt is None or pkt.addressee != self.callsign or pkt.src == self.callsign:
            return
        text = pkt.text.strip()
        log.info("RX %s -> %s: %r (id=%s)", pkt.src, pkt.addressee, text, pkt.msgid)

        ack = ACK_RE.match(text)
        if ack:
            self._on_ack(pkt.src, ack.group(1), ack.group(2))
            return

        if pkt.msgid:                       # selalu ACK, termasuk untuk duplikat
            self._transmit(format_ack(self.callsign, pkt.src, pkt.msgid))

        if self._is_duplicate(pkt.src, pkt.msgid, text):
            log.info("Duplikat dari %s diabaikan", pkt.src)
            return
        self.work_q.put((pkt.src, text, received_at))

    def _handle_server_comment(self, line):
        log.debug("SERVER %s", line)
        m = _LOGRESP_RE.search(line)
        if not m:
            return
        verified = m.group(1).lower() == "verified"
        self.can_transmit = verified and not self.dry_run
        if self.dry_run:
            log.info("Login OK. Mode --dry-run: bot TIDAK akan memancarkan apa pun.")
        elif verified:
            log.info("Login terverifikasi. Bot siap menerima pesan ke %s.", self.callsign)
            self._beacon_due = True
        else:
            log.warning("Login TIDAK terverifikasi (call sign/passcode salah?). "
                        "Bot hanya membaca, tidak bisa membalas.")

    def _is_duplicate(self, src, msgid, text):
        now = time.time()
        for key in [k for k, t in self._seen.items()
                    if now - t > (DEDUPE_TTL_ID if k[1] else DEDUPE_TTL_NOID)]:
            del self._seen[key]
        key = (src, msgid, text)
        if key in self._seen:
            return True
        self._seen[key] = now
        return False

    def _on_ack(self, src, kind, msgid):
        with self._pending_lock:
            entry = self.pending.pop((src, msgid), None)
        if entry:
            log.info("%s%s dari %s: pesan keluar %s selesai", kind, msgid, src, msgid)
        else:
            log.debug("%s%s dari %s tidak cocok dengan pesan yang menunggu", kind, msgid, src)

    # ------------------------------------------------------------------
    # Pemrosesan perintah (thread terpisah supaya pembacaan socket tidak macet)
    # ------------------------------------------------------------------
    def _worker_loop(self):
        while not self.stop_event.is_set():
            try:
                src, text, received_at = self.work_q.get(timeout=1)
            except queue.Empty:
                continue
            try:
                self.handle_command(src, text, received_at)
            except Exception:  # noqa: BLE001 - bot harus tetap hidup
                log.exception("Error memproses pesan dari %s", src)

    def handle_command(self, src, text, received_at=None):
        now = time.time()
        if now - self._last_cmd.get(src, 0) < config.RATE_LIMIT_SECONDS:
            log.info("Rate limit: pesan dari %s diabaikan", src)
            return
        history = self._replies[src]
        while history and now - history[0] > 3600:
            history.popleft()
        if len(history) >= config.MAX_REPLIES_PER_HOUR:
            log.info("Batas balasan per jam tercapai untuk %s", src)
            return
        self._last_cmd[src] = now
        history.append(now)

        try:
            reply = process_command(src, text, received_at)
        except Exception:  # noqa: BLE001
            log.exception("Handler perintah gagal")
            reply = "Maaf, bot sedang error. Coba lagi nanti. 73"
        if reply:
            self.send_text(src, reply)

    # ------------------------------------------------------------------
    # Pengiriman pesan keluar (dengan retry sampai di-ACK)
    # ------------------------------------------------------------------
    def _next_msgid(self):
        self._msg_counter = self._msg_counter % 99999 + 1
        return str(self._msg_counter)

    def send_text(self, dest, text):
        parts = split_message(sanitize_text(text))
        for i, part in enumerate(parts):
            msgid = self._next_msgid()
            line = format_message(self.callsign, dest, part, msgid)
            if self._transmit(line):
                with self._pending_lock:
                    self.pending[(dest.upper(), msgid)] = {
                        "line": line, "tries": 0,
                        "next": time.time() + RETRY_INTERVALS[0],
                    }
            if i < len(parts) - 1 and self.stop_event.wait(PART_GAP):
                return

    def _retry_loop(self):
        while not self.stop_event.wait(1):
            now = time.time()
            with self._pending_lock:
                due = [(k, e) for k, e in self.pending.items() if e["next"] <= now]
            for key, entry in due:
                entry["tries"] += 1
                if entry["tries"] > MAX_RETRIES:
                    with self._pending_lock:
                        self.pending.pop(key, None)
                    log.warning("Menyerah: %s tidak mengirim ACK untuk pesan %s", key[0], key[1])
                    continue
                log.info("Retry %d/%d ke %s (id %s)", entry["tries"], MAX_RETRIES, key[0], key[1])
                self._transmit(entry["line"])
                entry["next"] = now + RETRY_INTERVALS[min(entry["tries"], len(RETRY_INTERVALS) - 1)]

    # ------------------------------------------------------------------
    # Beacon
    # ------------------------------------------------------------------
    def _beacon_loop(self):
        while not self.stop_event.wait(5):
            if config.BEACON_INTERVAL <= 0 or not self.can_transmit:
                continue
            now = time.time()
            if self._beacon_due or now >= self._next_beacon:
                self._beacon_due = False
                self._next_beacon = now + config.BEACON_INTERVAL
                self.send_beacon()

    def send_beacon(self):
        if config.BEACON_POSITION:
            lat, lon = config.BEACON_POSITION
            self._transmit(format_position(self.callsign, lat, lon,
                                           config.BEACON_SYMBOL, config.BEACON_TEXT[:43]))
        self._transmit(format_status(self.callsign, config.BEACON_TEXT))


def _simulate(src, text):
    """Tes offline: tampilkan balasan persis seperti yang akan dikirim lewat APRS."""
    reply = process_command(src.upper(), text, datetime.now(timezone.utc))
    parts = split_message(sanitize_text(reply))
    print(f"\nPesan dari {src.upper()}: {text!r}")
    for i, part in enumerate(parts, 1):
        print(f"  balasan {i}/{len(parts)} ({len(part)} char): {part}")


def main():
    parser = argparse.ArgumentParser(description="APRS Bot Wisuda - Ilmu Informatika UKDC")
    parser.add_argument("--dry-run", action="store_true",
                        help="konek ke APRS-IS tapi tidak memancarkan apa pun")
    parser.add_argument("--simulate", nargs=2, metavar=("CALLSIGN", "TEKS"),
                        help="tes offline: anggap CALLSIGN mengirim TEKS ke bot")
    parser.add_argument("--debug", action="store_true", help="log lebih rinci")
    args = parser.parse_args()

    logging.basicConfig(level=logging.DEBUG if args.debug else logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")

    if args.simulate:
        _simulate(*args.simulate)
        return

    bot = AprsBot(dry_run=args.dry_run)
    if bot.callsign.startswith("N0CALL") or bot.passcode == "-1":
        log.warning("APRS_CALLSIGN/APRS_PASSCODE belum diisi -> mode BACA SAJA "
                    "(bot tidak akan membalas). Lihat config.py.")

    def _shutdown(*_):
        log.info("Menghentikan bot ...")
        bot.stop()

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)
    bot.run()


if __name__ == "__main__":
    main()
