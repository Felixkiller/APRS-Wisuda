# APRS Bot Wisuda – Ilmu Informatika UKDC

Peserta kirim pesan **WISUDA** ke call sign bot lewat APRS → bot menjawab ucapan
wisuda (otomatis, dengan ACK + retry) dan membuat **QSL card PNG** personal
(call sign pengirim, tanggal & jam UTC, 2M / 144.390 / 59 / PKT).

Zip ini lengkap dan berdiri sendiri (bukan patch): bot, QSL generator, artwork,
font, log, tes, dan skrip jalan.

## 1. Isi call sign & passcode (wajib agar bisa membalas)

Salin `.env.example` menjadi `.env`, lalu isi:

```
APRS_CALLSIGN=YD3XXX-5
APRS_PASSCODE=12345
```

Tanpa itu bot jalan dalam mode **baca saja** (tidak memancarkan apa pun).
Jangan bagikan file `.env` (berisi passcode).
Pengaturan lain (tanggal event, rate limit, beacon, posisi di peta) ada di `config.py`.

## 2. Jalankan

Butuh Python 3.9+.

| Sistem | Perintah |
|---|---|
| Windows | klik dua kali `run.bat` (atau `run.bat --dry-run`) |
| Linux / Mac / Raspberry Pi | `./run.sh` (atau `./run.sh --dry-run`) |

Skrip membuat folder `.venv`, memasang Pillow + tzdata sekali saja, lalu menjalankan bot.
Tanpa skrip: `pip install -r requirements.txt` lalu `python aprs_bot.py`.

Opsi:

```bash
python aprs_bot.py --simulate YB1ABC-7 wisuda   # tes offline, tanpa jaringan
python aprs_bot.py --dry-run                    # konek APRS-IS, tapi tidak memancarkan
python aprs_bot.py --debug                      # log rinci
```

Tes dari luar: di radio/aplikasi APRS (APRSdroid, dll.) kirim **pesan** ke call
sign bot dengan isi `WISUDA`. Perintah lain: `HELP`.

## Hasil

| Lokasi | Isi |
|---|---|
| `generated_cards/` | QSL card PNG per pengirim (APRS hanya teks, jadi kartu dibagikan manual) |
| `logs/callsigns.csv` | daftar call sign yang sudah QSO |
| `logs/events.csv` | log kejadian (diterima, kartu dibuat, dibalas) |

## Catatan

- **Tanggal & jam di kartu** = saat pesan pengirim tiba di bot, dalam UTC (standar QSL).
  Paket pesan APRS tidak membawa cap waktu, jadi ini yang paling mendekati waktu kirim.
- Bot memakai **APRS-IS** (internet). Pesan dari RF sampai ke bot kalau ada iGate
  yang menerimanya; balasan ke RF butuh iGate dengan TX di sekitar penerima.
- Balasan dipecah per 67 karakter (batas APRS), tiap bagian diulang sampai 3x
  bila belum di-ACK. Pengirim yang sama dibatasi 1 perintah / 20 detik dan 20 balasan / jam.
- `ENFORCE_EVENT_WINDOW = True` di `config.py` membuat bot hanya menjawab
  WISUDA antara `date_start` dan `date_end`. Ubah `date` / `date_start` / `date_end`
  sesuai jadwal wisuda.
- `fonts/` berisi DejaVu Sans (lisensi bebas) sebagai cadangan; kartu memakai
  Segoe UI/Arial bila ada di komputer.
- `qsl_generator.py` dan `modules/wisuda.py` berasal dari patch; perubahan hanya:
  parameter `qso_time` dan font cadangan. File `statistics.py` sengaja bernama itu
  agar patch cocok.
- Tes: `python -m unittest discover -s tests`
