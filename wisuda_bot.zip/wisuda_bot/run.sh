#!/usr/bin/env bash
# Pasang dependensi (sekali) lalu jalankan bot. Contoh:  ./run.sh   atau   ./run.sh --dry-run
set -e
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
.venv/bin/python -m pip install -q -r requirements.txt
exec .venv/bin/python aprs_bot.py "$@"
