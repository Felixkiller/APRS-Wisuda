"""
Modul Pembuat QSL Card - APRS Bot Ilmu Informatika UKDC

Membuat kartu QSL bertema Wisuda dengan isi seperti QSL special event:
  CONFIRM QSO WITH | DATE | TIME (UTC) | BAND | FREQ | RST | MODE | OPERATOR

- Artwork "Happy Graduation" dipakai sebagai gambar utama
- Call sign pengirim otomatis masuk ke kolom CONFIRM QSO WITH
- Tanggal & jam diambil saat pesan diterima (UTC)

Dipakai oleh modules/wisuda.py -> generate_qsl_card(from_call, event_config)
"""

import os
from datetime import datetime, timezone

from config import GENERATED_CARDS_DIR, TIMEZONE, CALLSIGN

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:  # pragma: no cover
    Image = ImageDraw = ImageFont = None

# ------------------------------------------------------------
# Ukuran kartu: 857 x 604 "unit" (sama seperti contoh QSL), dirender 2x
# ------------------------------------------------------------
W_UNITS, H_UNITS = 857, 604
S = 2          # skala output akhir (1714 x 1208 px)
K = 4          # skala supersampling untuk bentuk (supaya sudut halus)

NAVY = (20, 33, 61)
GOLD = (201, 162, 39)
RED = (192, 32, 38)
BLUE = (26, 79, 214)
CREAM = (248, 245, 237)
WHITE = (255, 255, 255)
GRAY = (120, 120, 120)

DEFAULT_QSL = {"band": "2M", "freq": "144.390", "rst": "59", "mode": "PKT"}
DEFAULT_QUOTE = (
    "Semoga ilmu yang diraih bermanfaat, membawa berkah, "
    "dan sukses selalu untuk ke depannya"
)

_FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")

_BOLD_FONTS = [
    "C:/Windows/Fonts/segoeuib.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/opentype/inter/Inter-Bold.otf",
    "/Library/Fonts/Arial Bold.ttf",
    os.path.join(_FONT_DIR, "DejaVuSans-Bold.ttf"),   # font bawaan paket (cadangan terakhir)
]
_REGULAR_FONTS = [
    "C:/Windows/Fonts/segoeui.ttf",
    "C:/Windows/Fonts/arial.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    "/usr/share/fonts/opentype/inter/Inter-Regular.otf",
    "/Library/Fonts/Arial.ttf",
    os.path.join(_FONT_DIR, "DejaVuSans.ttf"),        # font bawaan paket (cadangan terakhir)
]


def _font(size, bold=False):
    for path in (_BOLD_FONTS if bold else _REGULAR_FONTS):
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, int(size))
            except Exception:
                continue
    return ImageFont.load_default()


def _fit_font(draw, text, max_w, size, bold=False, min_size=10):
    """Kecilkan font sampai teks muat di lebar max_w (px)."""
    while size > min_size:
        f = _font(size, bold)
        box = draw.textbbox((0, 0), text, font=f)
        if box[2] - box[0] <= max_w:
            return f
        size -= 1
    return _font(min_size, bold)


def _wrap(draw, text, font, max_w):
    lines, cur = [], ""
    for word in text.split():
        test = f"{cur} {word}".strip()
        box = draw.textbbox((0, 0), test, font=font)
        if box[2] - box[0] > max_w and cur:
            lines.append(cur)
            cur = word
        else:
            cur = test
    if cur:
        lines.append(cur)
    return lines


def _base_callsign(call):
    """YE3ESW-6 -> YE3ESW (SSID tidak ditampilkan di QSL)."""
    return str(call).split("-")[0].strip().upper()


def _local_time():
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo(TIMEZONE))
    except Exception:
        from datetime import timedelta
        return datetime.now(timezone(timedelta(hours=7)))


def _draw_shapes(width, height):
    """Lapisan bentuk (kotak, band) pada resolusi K lalu diperkecil ke S."""
    k = K
    layer = Image.new("RGB", (W_UNITS * k, H_UNITS * k), CREAM)
    d = ImageDraw.Draw(layer)

    def R(box, r, fill=None, outline=None, w=1):
        x0, y0, x1, y1 = box
        d.rounded_rectangle(
            (x0 * k, y0 * k, x1 * k, y1 * k), radius=r * k,
            fill=fill, outline=outline, width=int(w * k),
        )

    # bingkai emas tipis
    R((6, 6, W_UNITS - 6, H_UNITS - 6), 10, outline=GOLD, w=2)
    # band atas navy + strip merah
    d.rectangle((0, 0, W_UNITS * k, 64 * k), fill=NAVY)
    d.rectangle((0, 64 * k, W_UNITS * k, 92 * k), fill=RED)
    # footer navy
    d.rectangle((0, 560 * k, W_UNITS * k, H_UNITS * k), fill=NAVY)

    # kotak isian QSL (kiri)
    for (x0, y0, x1, y1) in BOXES.values():
        R((x0, y0, x1, y1), 9, fill=WHITE, outline=(222, 216, 200), w=1)

    # panel artwork (kanan)
    R(PANEL, 14, fill=WHITE, outline=GOLD, w=2)

    return layer.resize((width, height), Image.LANCZOS)


# Tata letak kotak (unit)
_X0, _X1, _GAP = 24, 312, 8
_HALF = (_X1 - _X0 - _GAP) // 2
_BH, _BG, _Y = 72, 12, 114


def _row(i):
    y0 = _Y + i * (_BH + _BG)
    return y0, y0 + _BH


BOXES = {
    "CONFIRM QSO WITH": (_X0, _row(0)[0], _X1, _row(0)[1]),
    "DATE": (_X0, _row(1)[0], _X0 + _HALF, _row(1)[1]),
    "TIME": (_X0 + _HALF + _GAP, _row(1)[0], _X1, _row(1)[1]),
    "BAND": (_X0, _row(2)[0], _X0 + _HALF, _row(2)[1]),
    "FREQ": (_X0 + _HALF + _GAP, _row(2)[0], _X1, _row(2)[1]),
    "RST": (_X0, _row(3)[0], _X0 + _HALF, _row(3)[1]),
    "MODE": (_X0 + _HALF + _GAP, _row(3)[0], _X1, _row(3)[1]),
    "OPERATOR": (_X0, _row(4)[0], _X1, _row(4)[1]),
}
PANEL = (336, _Y, 833, _row(4)[1])


def generate_qsl_card(callsign, event_config, qso_time=None, output_path=None):
    """
    Membuat QSL card Wisuda untuk call sign pengirim.

    Args:
        callsign: Call sign pengirim APRS (SSID otomatis dibuang di kartu)
        event_config: Konfigurasi event 'wisuda' dari config.EVENTS_2026
        qso_time: datetime (UTC). Default: sekarang
        output_path: Path file hasil. Default: generated_cards/wisuda_<call>_<waktu>.png

    Returns:
        str: path file PNG, atau None jika gagal
    """
    if Image is None:
        print("[QSL] ERROR: Pillow belum terpasang. Jalankan: pip install Pillow")
        return None

    try:
        qsl = {**DEFAULT_QSL, **event_config.get("qsl", {})}
        title = event_config.get("title", "WISUDA 2026")
        quote = event_config.get("quote", DEFAULT_QUOTE)
        operator = qsl.get("operator") or _base_callsign(CALLSIGN)

        utc = (qso_time or datetime.now(timezone.utc)).astimezone(timezone.utc)
        values = {
            "CONFIRM QSO WITH": _base_callsign(callsign),
            "DATE": utc.strftime("%d-%m-%Y"),
            "TIME": utc.strftime("%H:%M UTC"),
            "BAND": qsl["band"],
            "FREQ": qsl["freq"],
            "RST": qsl["rst"],
            "MODE": qsl["mode"],
            "OPERATOR": operator,
        }

        width, height = W_UNITS * S, H_UNITS * S
        img = _draw_shapes(width, height)
        draw = ImageDraw.Draw(img)
        u = lambda v: int(v * S)

        # ---- Band atas ----
        draw.text((u(24), u(10)), "ILMU INFORMATIKA", font=_font(u(21), True), fill=WHITE)
        draw.text((u(24), u(37)), "Universitas Katolik Darma Cendika",
                  font=_font(u(12)), fill=(210, 216, 230))
        f_qsl = _font(u(27), True)
        f_title = _font(u(15), True)
        t1 = "QSL CARD"
        t2 = title.upper()
        for txt, f, y, col in ((t1, f_qsl, 6, GOLD), (t2, f_title, 40, WHITE)):
            bb = draw.textbbox((0, 0), txt, font=f)
            draw.text((width - u(24) - (bb[2] - bb[0]), u(y)), txt, font=f, fill=col)

        # ---- Strip merah ----
        strip = "SELAMAT WISUDA  \u2022  SUKSES SELALU UNTUK KE DEPANNYA"
        f_strip = _fit_font(draw, strip, width - u(48), u(15), bold=True)
        bb = draw.textbbox((0, 0), strip, font=f_strip)
        draw.text(((width - (bb[2] - bb[0])) // 2, u(78) - (bb[3] - bb[1]) // 2 - bb[1]),
                  strip, font=f_strip, fill=WHITE)

        # ---- Kotak isian ----
        f_label = _font(u(10.5), True)
        for label, (x0, y0, x1, y1) in BOXES.items():
            draw.text((u(x0 + 12), u(y0 + 9)), label, font=f_label, fill=GRAY)
            is_call = label == "CONFIRM QSO WITH"
            f_val = _fit_font(draw, values[label], u(x1 - x0 - 24),
                              u(34 if is_call else 24), bold=True)
            draw.text((u(x0 + 12), u(y0 + 28)), values[label], font=f_val,
                      fill=BLUE if is_call else RED)

        # ---- Panel artwork ----
        px0, py0, px1, py1 = PANEL
        art_path = event_config.get("image", "")
        art_w = u(440)
        art_h = 0
        if os.path.exists(art_path):
            art = Image.open(art_path).convert("RGB")
            art_h = int(art.height * art_w / art.width)
            art = art.resize((art_w, art_h), Image.LANCZOS)
            img.paste(art, (u(px0 + (px1 - px0 - 440) / 2), u(py0 + 8)))
        else:
            f_h = _font(u(34), True)
            txt = "Happy Graduation"
            bb = draw.textbbox((0, 0), txt, font=f_h)
            draw.text((u((px0 + px1) / 2) - (bb[2] - bb[0]) // 2, u(py0 + 90)),
                      txt, font=f_h, fill=NAVY)
            art_h = u(300)

        # garis pemisah + kutipan
        y_line = u(py0 + 8) + art_h + u(8)
        draw.line((u(px0 + 90), y_line, u(px1 - 90), y_line), fill=GOLD, width=max(2, S))
        f_quote = _font(u(15))
        lines = _wrap(draw, f"\u201c{quote}\u201d", f_quote, u(px1 - px0 - 56))
        y = y_line + u(10)
        for line in lines:
            bb = draw.textbbox((0, 0), line, font=f_quote)
            draw.text((u((px0 + px1) / 2) - (bb[2] - bb[0]) // 2, y), line,
                      font=f_quote, fill=NAVY)
            y += u(20)

        # ---- Footer ----
        draw.text((u(24), u(572)), "TNX FER QSO  \u2022  73!", font=_font(u(15), True), fill=GOLD)
        foot = f"{CALLSIGN} BOT - ILMU INFORMATIKA UKDC"
        f_foot = _font(u(12))
        bb = draw.textbbox((0, 0), foot, font=f_foot)
        draw.text((width - u(24) - (bb[2] - bb[0]), u(574)), foot, font=f_foot,
                  fill=(210, 216, 230))

        # ---- Simpan ----
        if not output_path:
            os.makedirs(GENERATED_CARDS_DIR, exist_ok=True)
            safe = str(callsign).replace("/", "_").replace("\\", "_")
            stamp = _local_time().strftime("%Y%m%d_%H%M%S")
            key = event_config.get("command_trigger", "wisuda")
            output_path = os.path.join(GENERATED_CARDS_DIR, f"{key}_{safe}_{stamp}.png")
        img.save(output_path)
        print(f"[QSL] Generated: {output_path}")
        return output_path

    except Exception as e:
        print(f"[QSL] Error generating QSL card: {e}")
        return None
