"""Pencarian event berdasarkan kata kunci (trigger) pesan APRS."""

from datetime import date, datetime

import config


def get_event_by_trigger(trigger):
    """Return (key, config_event) untuk trigger yang cocok, atau (None, None)."""
    trigger = (trigger or "").strip().lower()
    if not trigger:
        return None, None
    for key, event in config.EVENTS_2026.items():
        if str(event.get("command_trigger", "")).lower() == trigger:
            return key, event
    return None, None


def _today_local():
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo(config.TIMEZONE)).date()
    except Exception:
        return date.today()


def is_event_active(event, today=None):
    """True kalau hari ini ada di antara date_start dan date_end (inklusif)."""
    today = today or _today_local()
    try:
        start = date.fromisoformat(event["date_start"])
        end = date.fromisoformat(event["date_end"])
    except (KeyError, ValueError):
        return True  # tanggal tidak diisi = selalu aktif
    return start <= today <= end


def describe_window(event):
    """Teks rentang aktif event, mis. '25-11-2026 s/d 05-12-2026'."""
    try:
        start = date.fromisoformat(event["date_start"]).strftime("%d-%m-%Y")
        end = date.fromisoformat(event["date_end"]).strftime("%d-%m-%Y")
        return f"{start} s/d {end}"
    except (KeyError, ValueError):
        return "-"
