"""
Pencatatan aktivitas bot (nama file `statistics.py` dipertahankan supaya
modules/wisuda.py dari patch bisa dipakai apa adanya).

Output:
  logs/callsigns.csv : siapa saja yang sudah QSO (waktu UTC, call, event, perintah)
  logs/events.csv    : log kejadian (RECEIVED, CARD_GENERATED, REPLIED, ...)
"""

import csv
import os
import threading
from datetime import datetime, timezone

import config

_lock = threading.Lock()


def _append(filename, header, row):
    try:
        os.makedirs(config.LOG_DIR, exist_ok=True)
        path = os.path.join(config.LOG_DIR, filename)
        new_file = not os.path.exists(path)
        with _lock, open(path, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            if new_file:
                writer.writerow(header)
            writer.writerow(row)
    except OSError as exc:  # logging tidak boleh menjatuhkan bot
        print(f"[STAT] gagal menulis {filename}: {exc}")


def _now_utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def log_callsign(call, event_name, command):
    _append("callsigns.csv", ["utc", "callsign", "event", "command"],
            [_now_utc(), call, event_name, command])


def log_event(kind, call, detail=""):
    _append("events.csv", ["utc", "kind", "callsign", "detail"],
            [_now_utc(), kind, call, detail])
